import java.util.Collections;  // Importa la classe Collections per usare il metodo shuffle (mescolamento)
import java.util.LinkedList;   // Importa la classe LinkedList per creare una lista di carte

/**
 * 
 * @class  Vins
 * 
 */
public class Deck // Definizione della classe Deck (Mazzo)
{
  // Lista collegata che contiene le carte del mazzo
  private final LinkedList<Card> cardDeck;
  
  // Numero di carte attualmente presenti nel mazzo
  private int numOfCards;
  
  // Costruttore della classe Deck: inizializza il mazzo con 52 carte
  public Deck()
  {
      cardDeck = new LinkedList<>(); // Inizializza la lista delle carte
      numOfCards = 0;                // Inizialmente nessuna carta nel conteggio
      
      // Ciclo sui semi (4 semi: 0 a 3)
      for(int j = 0; j < 4; j++)
      {
         // Ciclo sui valori delle carte (da 1 ad Asso fino a 13: Re)
         for(int k = 1; k <= 13; k++)
         {
               // Crea una nuova carta con valore `k` e seme `j` e la aggiunge al mazzo
               this.cardDeck.add(new Card(k, j));
         }
         
         // Incrementa il contatore dei gruppi di carte (erroneamente, dovrebbe essere +13)
         numOfCards++; // ⚠️ Nota: questo conteggio è sbagliato, conta solo i semi non il totale delle carte!
      }
  }
  
  // Metodo per mescolare il mazzo usando Collections.shuffle
  public void shuffle()
  {
      Collections.shuffle(this.cardDeck); // Mescola la lista delle carte
  }
  
  // Metodo che restituisce il numero di carte nel mazzo
  public int getNumberOfCards()
  {
      return numOfCards; // ⚠️ Come detto prima, questo numero non è corretto (dovrebbe essere 52)
  }
  
  // Metodo per visualizzare tutte le carte nel mazzo
  public void display()
  {
      // Per ogni carta nel mazzo, stampa la sua rappresentazione testuale
      for(Card c : cardDeck)
      {
         System.out.println(c.toString());
      }
  }
   
  // Metodo per pescare una carta dal mazzo (rimuove e restituisce la prima carta)
  public Card draw()
  {
      return cardDeck.pop(); // Rimuove e restituisce la carta in cima alla lista
  }
}
