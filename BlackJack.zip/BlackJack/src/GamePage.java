

/**
 *
 * @author Vins
 */
public class GamePage extends javax.swing.JFrame {

    /**
     * Creates new form GamePage
     */
    Deck gameDeck = new Deck();
    Hand playerHand = new Hand();
    Hand dealerHand = new Hand();
    Integer bet ;
    public static int bank = 10000;
    
    
    
    
    public GamePage() {
    // Inizializza i componenti grafici della finestra (UI)
    initComponents(); 
    
    // Mischia il mazzo di carte due volte per garantire che l'ordine delle carte sia casuale
    gameDeck.shuffle();  // Mischia il mazzo
    gameDeck.shuffle();  // Mischia il mazzo di nuovo
    
    // Aggiunge una carta alla mano del giocatore
    playerHand.addCard(gameDeck.draw());  // Pesca una carta dal mazzo e la aggiunge alla mano del giocatore
    
    // Imposta l'icona della prima carta del giocatore (playerCard1)
    // Usa il seme e il valore della carta per caricare l'immagine corrispondente
    playerCard1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + playerHand.lastCard().getSuitAsString() + "/" + playerHand.lastCard().getValueAsString() + ".png")));
    
    // Aggiunge una carta alla mano del dealer
    dealerHand.addCard(gameDeck.draw());  // Pesca una carta dal mazzo e la aggiunge alla mano del dealer
    
    // Imposta l'icona della prima carta del dealer (dealerCard1)
    // Usa il seme e il valore della carta per caricare l'immagine corrispondente
    dealerCard1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + dealerHand.lastCard().getSuitAsString() + "/" + dealerHand.lastCard().getValueAsString() + ".png")));
    
    // Aggiunge una seconda carta alla mano del giocatore
    playerHand.addCard(gameDeck.draw());  // Pesca un'altra carta dal mazzo e la aggiunge alla mano del giocatore
    
    // Imposta l'icona della seconda carta del giocatore (playerCard2)
    // Usa il seme e il valore della carta per caricare l'immagine corrispondente
    playerCard2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + playerHand.lastCard().getSuitAsString() + "/" + playerHand.lastCard().getValueAsString() + ".png")));
}

    
    public void setBet(String s) {
    // Converte la stringa s in un numero intero e lo assegna alla variabile bet
    this.bet = Integer.parseInt(s);  
    
    // Riduce il saldo bancario del giocatore (bank) di un importo pari alla puntata (bet)
    bank -= bet;
    
    // Aggiorna l'etichetta del saldo bancario del giocatore (playerBank) con il nuovo valore del saldo
    playerBank.setText(Integer.toString(bank));  // Converte il saldo bancario in stringa e lo visualizza
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        playerCard4 = new javax.swing.JLabel();
        playerCard3 = new javax.swing.JLabel();
        playerCard2 = new javax.swing.JLabel();
        playerCard1 = new javax.swing.JLabel();
        dealerCard4 = new javax.swing.JLabel();
        dealerCard3 = new javax.swing.JLabel();
        dealerCard2 = new javax.swing.JLabel();
        dealerCard1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        playerBank = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton3.setBackground(new java.awt.Color(0, 102, 51));
        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton3.setText("Exit");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1730, 10, 100, 50));

        jButton4.setBackground(new java.awt.Color(0, 102, 51));
        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton4.setText("Resetta");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1730, 80, 100, 50));

        playerCard4.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(playerCard4, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 640, 80, 100));

        playerCard3.setForeground(new java.awt.Color(255, 255, 255));
        playerCard3.setMaximumSize(new java.awt.Dimension(18, 14));
        playerCard3.setMinimumSize(new java.awt.Dimension(18, 14));
        playerCard3.setPreferredSize(new java.awt.Dimension(18, 14));
        getContentPane().add(playerCard3, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 640, 80, 100));

        playerCard2.setForeground(new java.awt.Color(255, 255, 255));
        playerCard2.setToolTipText("");
        getContentPane().add(playerCard2, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 640, 80, 100));

        playerCard1.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(playerCard1, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 640, 80, 100));

        dealerCard4.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(dealerCard4, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 170, 160, 260));

        dealerCard3.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(dealerCard3, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 160, 140, 230));

        dealerCard2.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(dealerCard2, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 160, 140, 210));

        dealerCard1.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(dealerCard1, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 160, 140, 210));

        jButton1.setBackground(new java.awt.Color(0, 102, 51));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton1.setText("Hit");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 950, 80, -1));

        jButton2.setBackground(new java.awt.Color(0, 102, 51));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton2.setText("Stand");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 950, 73, -1));

        playerBank.setForeground(new java.awt.Color(255, 255, 255));
        playerBank.setText("Conto");
        getContentPane().add(playerBank, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 950, 110, 20));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 40)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Proprie Carte");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 570, 260, 40));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 40)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Carte Del Dealer");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 80, 320, 60));

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Backgrounds/papa.jpg"))); // NOI18N
        jLabel1.setText("4");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 1870, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        
      
            
        dealerHand.addCard(gameDeck.draw());
        
          
        if(dealerHand.getNumberOfCards()==2)
        dealerCard2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/"+dealerHand.lastCard().getSuitAsString()+"/"+dealerHand.lastCard().getValueAsString()+".png")));
        else if(dealerHand.getNumberOfCards()==3)
        dealerCard3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/"+dealerHand.lastCard().getSuitAsString()+"/"+dealerHand.lastCard().getValueAsString()+".png")));
        else if(dealerHand.getNumberOfCards()==4)
        dealerCard4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/"+dealerHand.lastCard().getSuitAsString()+"/"+dealerHand.lastCard().getValueAsString()+".png")));
            
          
         // Controlla se il Dealer ha un Blackjack
    if (dealerHand.getHandValue() == 21 && dealerHand.getNumberOfCards() == 2) {
        WinScreen w = new WinScreen();
        w.setVisible(true);  
        this.dispose();
    }
    
    // Controlla se il Giocatore ha un Blackjack
    if (playerHand.getHandValue() == 21 && playerHand.getNumberOfCards() == 2) {
        WinScreen w = new WinScreen();
        w.setVisible(true);  
        this.dispose();
    }
        
        
        //} while(dealerHand.getNumberOfCards() <= 4);
        
        if(dealerHand.getHandValue()>21 && playerHand.getHandValue()>21)
        {
            bank += bet;
            PushScreen p = new PushScreen();
            p.setVisible(true);
            
            
        }
        else if(dealerHand.getHandValue()>21 && playerHand.getHandValue()<=21)
        {
            bank += 2*bet;
            WinScreen w = new WinScreen();
            w.setVisible(true);   
            
        }
        if(playerHand.getHandValue()>21)
        {
            bank -= bet;
            LoseScreen l = new LoseScreen();
            l.setVisible(true);
            
        }
        else if(dealerHand.getHandValue() == playerHand.getHandValue())
        {
            bank += bet;
            PushScreen p = new PushScreen();
            p.setVisible(true);
            
        }
        else if(dealerHand.getHandValue() > playerHand.getHandValue())
        {
            bank -= bet;
            LoseScreen l = new LoseScreen();
            l.setVisible(true);      
            
        }
        else if(playerHand.getHandValue() > dealerHand.getHandValue() )
        {
            bank += 2*bet;
            WinScreen w = new WinScreen();
            w.setVisible(true);   
            
        }    
            
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        
        
        
        playerHand.addCard(gameDeck.draw());
        if(playerHand.getHandValue()>21)
        {
        LoseScreen l = new LoseScreen();
            l.setVisible(true);
            this.dispose();
        }
        
        System.out.println(playerHand.getHandValue());
        
        if(playerHand.getNumberOfCards()==3)
        playerCard3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/"+playerHand.lastCard().getSuitAsString()+"/"+playerHand.lastCard().getValueAsString()+".png")));
        else if(playerHand.getNumberOfCards()==4)
        playerCard4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/"+playerHand.lastCard().getSuitAsString()+"/"+playerHand.lastCard().getValueAsString()+".png")));
        
        
        
        
       
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        
        
        dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        dispose();
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GamePage().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel dealerCard1;
    private javax.swing.JLabel dealerCard2;
    private javax.swing.JLabel dealerCard3;
    private javax.swing.JLabel dealerCard4;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel playerBank;
    private javax.swing.JLabel playerCard1;
    private javax.swing.JLabel playerCard2;
    private javax.swing.JLabel playerCard3;
    private javax.swing.JLabel playerCard4;
    // End of variables declaration//GEN-END:variables
}
