

/**
 *
 * @author Vins
 */
public class Card // Definizione della classe Card (Carta)
{
    // Costanti che rappresentano i semi delle carte (con codici numerici)
    public final static int SPADES = 0;     // Picche
    public final static int HEARTS = 1;     // Cuori
    public final static int DIAMONDS = 2;   // Quadri
    public final static int CLUBS = 3;      // Fiori
                            
    // Costanti che rappresentano i valori speciali delle carte
    public final static int ACE = 1,        // Asso
                            JACK = 10,      // Jack (valore 10)
                            QUEEN = 10,     // Regina (valore 10)
                            KING = 10;      // Re (valore 10)
                            
    // Attributo che rappresenta il valore numerico della carta (da 1 a 11)
    private final int value;
    // Attributo che rappresenta il seme della carta (Picche, Cuori, Quadri, Fiori)
    private final int suit;
    
    // Costruttore della classe Card: crea una carta con valore e seme specificati
    public Card(int theValue, int theSuit) 
    {
        value = theValue; // Assegna il valore passato
        suit = theSuit;   // Assegna il seme passato
    }
    
    // Metodo che restituisce il valore numerico della carta
    public int getValue() 
    {
        return value;
    }
    
    // Metodo che restituisce il seme della carta come codice numerico
    public int getSuit() 
    {
        return suit;
    }
    
    // Metodo che restituisce il seme della carta come stringa
    public String getSuitAsString() 
    {
        // Se il codice del seme è valido, restituisce il nome del seme
        // Altrimenti restituisce "Invalid Suit Code"
        switch ( suit ) 
        {
           case SPADES:   return "picche";    // Picche
           case HEARTS:   return "cuori";    // Cuori
           case DIAMONDS: return "quadri";  // Quadri
           case CLUBS:    return "fiori";     // Fiori
           default:       return "Invalid Suit Code"; // Codice non valido
        }
    }
    
    // Metodo che restituisce il valore della carta come stringa
    public String getValueAsString() 
    {
        // Se il valore è valido, restituisce la stringa corrispondente
        // Altrimenti restituisce "Invalid Value Code"
        switch ( value ) 
        {
           case 1:   return "Ace";     // Asso
           case 2:   return "2";
           case 3:   return "3";
           case 4:   return "4";
           case 5:   return "5";
           case 6:   return "6";
           case 7:   return "7";
           case 8:   return "8";
           case 9:   return "9";
           case 10:  return "10";
           case 11:  return "Jack";    // Jack
           case 12:  return "Queen";   // Regina
           case 13:  return "King";    // Re
           default:  return "Invalid Value Code"; // Valore non valido
        }
    }
    
    // Metodo che restituisce una rappresentazione in stringa della carta
    public String toString() 
    {
        // Restituisce una stringa nella forma "Valore di Seme"
        return getValueAsString() + " of " + getSuitAsString();
    }

}
