import java.util.LinkedList; // Importa la classe LinkedList per gestire la mano di carte

public class Hand { // Definizione della classe Hand (Mano)
    
    private LinkedList<Card> hand; // Lista collegata che rappresenta le carte nella mano

    public Hand() {
        hand = new LinkedList<>(); // Inizializza la mano come lista vuota
    }

    // Metodo per aggiungere una carta alla mano
    public void addCard(Card c) {
        hand.add(c); // Aggiunge la carta c alla lista
    }

    // Metodo per ottenere l'ultima carta aggiunta alla mano
    public Card lastCard() {
        return hand.getLast(); // Restituisce l'ultima carta nella lista
    }

    // Metodo che restituisce il numero di carte nella mano
    public int getNumberOfCards() {
        return hand.size(); // Restituisce la dimensione della lista
    }

    // Metodo che calcola e restituisce il valore totale della mano
    public int getHandValue() {
        int total = 0;       // Valore totale della mano
        int aceCount = 0;    // Conteggio degli assi nella mano

        // Ciclo su ogni carta nella mano
        for (Card c : hand) {
            int value = c.getValue(); // Ottiene il valore della carta

            if (value > 10) {
                total += 10; // Se è Jack, Queen o King, aggiunge 10
            } else if (value == 1) {
                total += 11; // Assumiamo inizialmente Asso = 11
                aceCount++; // Conta il numero di assi
            } else {
                total += value; // Aggiunge il valore normale (2-10)
            }
        }

        // Se il totale supera 21 e ci sono assi, converte ogni asso da 11 a 1
        while (total > 21 && aceCount > 0) {
            total -= 10; // Sottrae 10 per ogni asso (11 → 1)
            aceCount--;  // Diminuisce il conteggio degli assi convertiti
        }

        return total; // Restituisce il valore totale della mano
    }
}
